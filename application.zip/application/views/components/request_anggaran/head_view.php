<thead>
    <tr>
        <th rowspan="2" class="align-middle text-uppercase text-secondary">No Unit</th>
        <th rowspan="2" class="align-middle text-uppercase text-secondary">Kode Anggaran</th>
        <th rowspan="2" class="align-middle text-uppercase text-secondary">Nama Akun</th>
        <th rowspan="2" class="align-middle text-uppercase text-secondary">Unit Kerja</th>
        <th rowspan="2" class="align-middle text-uppercase text-secondary">Unit Bisnis</th>
        <th colspan="2"class="text-center text-uppercase text-secondary">Jumlah (Rp)</th>
        <th rowspan="2" class="align-middle text-uppercase text-secondary">Keterangan</th>
    </tr>
    
    <tr>
        <th class="text-center text-uppercase text-secondary">Diajukan</th>
        <th class="text-center text-uppercase text-secondary">Diterima</th>
    </tr>
</thead>