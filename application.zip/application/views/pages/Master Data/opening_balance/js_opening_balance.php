<script>

    $('#select-account-list').change(function () {
        $('#filter-account-list').submit();
    });

</script>
