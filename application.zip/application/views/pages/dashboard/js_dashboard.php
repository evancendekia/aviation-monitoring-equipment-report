
<!-- Morris Chart JS-->
<script src="<?php echo base_url();?>assets/universal/assets/js/morris-chart/raphael.js"></script>
<script src="<?php echo base_url();?>assets/universal/assets/js/morris-chart/morris.js"></script>

<!--Height Equal Js-->
<script src="<?php echo base_url();?>assets/universal/assets/js/height-equal.js"></script>

<!--Sparkline  Chart JS-->
<script src="<?php echo base_url();?>assets/universal/assets/js/sparkline/sparkline.js"></script>

<!-- prism js -->
<script src="<?php echo base_url();?>assets/universal/assets/js/prism/prism.min.js"></script>
