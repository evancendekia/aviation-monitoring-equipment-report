<div class="container-fluid">
                <div class="page-header">
                    <div class="row">
                        <div class="col-lg-6">
                            <h3><?php echo $menu;?>
                                <small>AME-R - Aviation Monitoring Equipment & Report</small>
                            </h3>
                        </div>
                        <div class="col-lg-6">
                            <ol class="breadcrumb pull-right">
                                <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i></a></li>
                                <li class="breadcrumb-item text-uppercase"><?php echo $menu;?></li>
                                <li class="breadcrumb-item active text-uppercase"><?php echo str_replace("_"," ",($page == 'equipment' ? 'sarfas' : $page));?></li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>