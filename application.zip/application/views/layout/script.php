
<!-- latest jquery-->
<script src="<?php echo base_url();?>assets/universal/assets/js/jquery-3.2.1.min.js" ></script>

<!-- Bootstrap js-->
<script src="<?php echo base_url();?>assets/universal/assets/js/bootstrap/popper.min.js" ></script>
<script src="<?php echo base_url();?>assets/universal/assets/js/bootstrap/bootstrap.js" ></script>

<!-- owlcarousel js-->
<script src="<?php echo base_url();?>assets/universal/assets/js/owlcarousel/owl.carousel.js" ></script>

<!-- Sidebar jquery-->
<script src="<?php echo base_url();?>assets/universal/assets/js/sidebar-menu.js" ></script>

<!-- clipboard js -->
<script src="<?php echo base_url();?>assets/universal/assets/js/clipboard/clipboard.min.js" ></script>

<!-- custom card js  -->
<script src="<?php echo base_url();?>assets/universal/assets/js/custom-card/custom-card.js" ></script>

<!-- Chart JS-->
<script src="<?php echo base_url();?>assets/universal/assets/js/chart/Chart.min.js"></script>






<!-- Theme js-->
<script src="<?php echo base_url();?>assets/universal/assets/js/script.js" ></script>
<!-- <script src="<?php echo base_url();?>assets/universal/assets/js/theme-customizer/customizer.js"></script> -->
<!-- <script src="<?php echo base_url();?>assets/universal/assets/js/chat-sidebar/chat.js"></script> -->
<script src="<?php echo base_url();?>assets/universal/assets/js/dashboard-default.js" ></script>

<!-- Counter js-->
<script src="<?php echo base_url();?>assets/universal/assets/js/counter/jquery.waypoints.min.js"></script>
<script src="<?php echo base_url();?>assets/universal/assets/js/counter/jquery.counterup.min.js"></script>
<script src="<?php echo base_url();?>assets/universal/assets/js/counter/counter-custom.js"></script>

<!-- menampilkan loading diawal load page -->
<!-- <script src="<?php echo base_url();?>assets/universal/assets/js/notify/bootstrap-notify.min.js"></script>
<script src="<?php echo base_url();?>assets/universal/assets/js/notify/index.js"></script> -->


<!-- Select2 js -->
<script type="text/javascript" src="<?php echo base_url();?>assets/universal/assets/js/select2/select2.full.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/universal/assets/js/select2/select2-custom.js"></script>

<!-- price format -->
<script type="text/javascript" src="<?php echo base_url();?>assets/universal/assets/js/jquery.priceformat.min.js"></script>

<!-- sweat alert -->
<script type="text/javascript" src="<?php echo base_url();?>assets/universal/assets/js/sweet-alert/sweetalert.min.js"></script>

<!-- date picker -->

<script type="text/javascript" src="<?php echo base_url();?>assets/universal/assets/js/date-picker/datepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/universal/assets/js/date-picker/datepicker.id.js"></script>